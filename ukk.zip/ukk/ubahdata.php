<title>Tambah Data Siswa</title>
<style>
    *{
        text-decoration: none;
    }
    body{
        background-image: url(<?php echo "background.png";?>);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }
     .bd{
        display: flex;
        height: 100vh;
        justify-content: center;
        align-items: center;
        background-color: rgb(148, 148, 148);
        font-family: Arial, Helvetica, sans-serif;
    }
    .box{
        width: 300px;
        min-height: 350px;
        border: 1px  rgb(253, 223, 0) solid;
        border-radius: 12px;
        background-color: orange;
        padding: 15px;
        box-sizing: border-box;
        margin-top: 5%;
    }
    .box h2{
        margin-bottom: 20px;
        color: black;
        font-family: Arial, Helvetica, sans-serif;
    }
    .input{
        width: 100%;
        padding: 10px;
        margin-bottom: 40px;
        box-sizing: border-box;
    }
    .btn{
        padding: 8px 15px;
        background-color: rgb(253, 223, 0);
        color: black;
        border: none;
        cursor: pointer;
        margin-bottom: 0px;
    }
    .btn a{
        color: black;
    }
</style>
<body class="bd">
<form method="POST" enctype="multipart/form-data" class="box">
    <h2>ID</h2>
    <input type="number" name="id" placeholder="ID">
    <h2>Nama</h2>
    <input type="text" name="nama" placeholder="Nama">
    <h2>Tempat Lahir</h2>
    <input type="text" name="tplahir" placeholder="Tempat Lahir">
    <h2>Tanggal Lahir</h2>
    <input type="date" name="tglahir" placeholder="Tanggal Lahir">
    <h2>Alamat</h2>
    <input type="text" name="alamat" placeholder="Alamat">
    <h2>Hobi</h2>
    <input type="text" name="hobi" placeholder="Hobi">
    <h2>Cita-cita</h2>
    <input type="text" name="cita_cita" placeholder="Cita-cita">
    <h2>Jumlah Saudara</h2>
    <input type="number" name="jm_saudara" placeholder="Jumlah Saudara">
    <h2>ID Kelas</h2>
    <input type="number" name="idkelas" placeholder="ID Kelas">
    <h2>ID Agama</h2>
    <input type="number" name="idagama" placeholder="ID Agama">
    <br><br>
    <input type="submit" name="konfirmasi" value="Konfirmasi" class="btn">
    <button class="btn"><a href="\ukk\tampildata.php">Kembali</a></button>
</form>
</body>
<?php
include 'konek.php';
if (isset($_POST['konfirmasi'])){
    mysqli_query($koneksi, "insert into tb_siswa set id='$_POST[id]', nama='$_POST[nama]', tplahir='$_POST[tplahir]', tglahir='$_POST[tglahir]', 
    alamat='$_POST[alamat]', hobi='$_POST[hobi]', cita_cita='$_POST[cita_cita]', jm_saudara='$_POST[jm_saudara]', idkelas='$_POST[idkelas]', idagama='$_POST[idagama]'");
}
?>