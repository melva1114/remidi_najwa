<title>Menampilkan Data</title>
<style>
    body{
        justify-content:center;
        background-image: url(<?php echo"background.png;?>);
        background-repeat: no-repeat;
        background attachment: fixed;
        background-size: cover;
    }
    table{
        border-collapse:collapse;
        width:50%;
        margin-top:5%;
        margin-left:25%;
        font-family: Times New Roman;
        background-color:blue;
    }
    <style>
    body{
        justify-content: center;
        background-image: url(<?php echo "background.png;?>);
        background-repeat: no-repeat;
        background-attachment: fixed;
        background-size: cover;
    }
    table{
        border-collapse: collapse;
        width: 50%;
        margin-top: 5%;
        margin-left: 25%;
        font-family: Times New Roman;
        background-color: blue;
    }
    tr, td{
        text-align: center;
    }
    a{
        text-decoration: none;
        cursor: pointer;
        color: white;
    }
    .btn{
        padding: 15px 10px;
        background-color: rgb(253, 223, 0);
        color: white;
        border: none;
        cursor: pointer;
        margin-bottom: 0px;

    }
    </style>
<body>
<div class="box">
<table border="2px white solid">
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Tempat Lahir</th>
        <th>Tanggal Lahir</th>
        <th>Alamat</th>
        <th>Hobi</th>
        <th>Cita-cita</th>
        <th>Jumlah Saudara</th>
        <th>ID Kelas</th>
        <th>ID Agama</th>
        <th>Edit</th>
        <th>Hapus</th>
    </tr>
    <?php
    include 'konek.php';
    $data = mysqli_query($koneksi, "select * from siswa");
    while ($tam = mysqli_fetch_array($data)){
    ?>
    <tr>
        <td><?php echo $tam['id'] ?></td>
        <td><?php echo $tam['nama'] ?></td>
        <td><?php echo $tam['tplahir'] ?></td>
        <td><?php echo $tam['tglahir'] ?></td>
        <td><?php echo $tam['alamat'] ?></td>
        <td><?php echo $tam['hobi'] ?></td>
        <td><?php echo $tam['cita_cita'] ?></td>
        <td><?php echo $tam['jm_saudara'] ?></td>
        <td><?php echo $tam['idkelas'] ?></td>
        <td><?php echo $tam['idagama'] ?></td>
        <?php
        echo "<td><a href='\biodatamelva\editdata.php?id=$tam[id]'>Edit</a></td>
        <td><a href=?id=$tam[id]>Hapus</a></td>"
        ;
        ?>
   </tr>
    <?php }?>
</table>
<table border="2px white solid">
<tr>
        <th>ID</th>
        <th>Nama Kelas</th>
        <th>Kompetensi</th>
        <th>Tahun Pelajaran</th>
        <th>Keterangan</th>
        <th>Edit</th>
        <th>Hapus</th>
    </tr>
    <?php
    include 'konek.php';
    $data = mysqli_query($koneksi, "select * from kelas");
    while ($tam = mysqli_fetch_array($data)){
    ?>
    <tr>
        <td><?php echo $tam['id'] ?></td>
        <td><?php echo $tam['namakelas'] ?></td>
        <td><?php echo $tam['kompetensi'] ?></td>
        <td><?php echo $tam['tahun_pelajaran'] ?></td>
        <td><?php echo $tam['keterangan'] ?></td>
        <?php
        echo "<td><a href='\biodatamelva/editkelas.php?id=$tam[id]'>Edit</a></td>
        <td><a href=?id=$tam[id]>Hapus</a></td>"
        ;
        ?>
   </tr>
    <?php }?>
</table>

<table  border="2px white solid">
<tr>
        <th>ID</th>
        <th>Nama Agama</th>
        <th>Edit</th>
        <th>Hapus</th>
    </tr>
    <?php
    include 'konek.php';
    $data = mysqli_query($koneksi, "select * from agama");
    while ($tam = mysqli_fetch_array($data)){
    ?>
    <tr>
        <td><?php echo $tam['idagama'] ?></td>
        <td><?php echo $tam['nm_agama'] ?></td>
        <?php
        echo "<td><a href='\biodatamelva/editagama.php?id=$tam[idagama]'>Edit</a></td>
        <td><a href=?id=$tam[idagama]>Hapus</a></td>"
        ;
        ?>
   </tr>
    <?php }?>
</table>
<br><br>
<button class="btn" style="margin-left: 25%;"><a href="\melva\tambahdata.php">Tambah Data Siswa</a></button>
<button class="btn"><a href="\melva\tambahkelas.php">Kelola Kelas</a></button>
<button class="btn"><a href="\melva\tambahagama.php">Kelola Agama</a></button>
<button class="btn"><a href="\melva\login.php">Logout</a></button>
</div>
</body>
<?php 
include 'konek.php';
if (isset($_GET['id'])) {
   mysqli_query($koneksi, "delete from siswa where id= $_GET[id]");
}
?>